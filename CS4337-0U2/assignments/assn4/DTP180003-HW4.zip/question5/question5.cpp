#include <iostream>

/*
Drew Pulliam – DTP180003
Assignment 4
CS 4337.0U2 
*/

int main() {
  std::cout << (10 * 2 + 3) << std::endl;
}