% Assignment 5 - Q3
% Drew Pulliam - DTP180003
% CS4337.0U2

delements(L, L1) :-  
    append(L1, [_,_,_], L).